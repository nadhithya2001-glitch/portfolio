// Export all components from a single file for easier imports
export { default as Navbar } from './Navbar';
export { default as Hero } from './Hero';
export { default as About } from './About';
export { default as Skills } from './Skills';
export { default as Education } from './Education';
export { default as Projects } from './Projects';
export { default as Certifications } from './Certifications';
export { default as Contact } from './Contact';
export { default as Footer } from './Footer';
export { default as ScrollToTop } from './ScrollToTop';
export { default as ParticleBackground } from './ParticleBackground';
export { default as AIChat } from './AIChat';
